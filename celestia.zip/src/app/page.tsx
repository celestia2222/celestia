import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function Home() {
  return (
    <main className="min-h-screen bg-white text-black px-6 py-10 max-w-4xl mx-auto">
      <section className="text-center mb-16">
        <h1 className="text-4xl font-bold mb-4">Celestia</h1>
        <p className="text-lg text-gray-600">
          Discover your cosmic self. Explore astrology, dive into celestial cycles, and align with the universe.
        </p>
      </section>

      <section className="mb-16">
        <h2 className="text-2xl font-semibold mb-4">About</h2>
        <p className="text-gray-700">
          Celestia is a modern, minimalistic astrology space designed for those who seek clarity, insight, and connection with the cosmos. Whether you're a beginner or an astro-pro, our content is here to guide you through lunar cycles, natal charts, transits, and more — in a clear, intuitive way.
        </p>
      </section>

      <section className="mb-16">
        <h2 className="text-2xl font-semibold mb-4">Latest Blog Posts</h2>
        <div className="grid gap-6">
          <Card>
            <CardContent className="p-4">
              <h3 className="text-xl font-bold">The Power of the Full Moon in Aquarius</h3>
              <p className="text-sm text-gray-600 mt-2">A deep dive into emotional freedom and breakthrough energy during this airy lunation.</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <h3 className="text-xl font-bold">Your Rising Sign: The Mask You Wear</h3>
              <p className="text-sm text-gray-600 mt-2">Understand the key to how others see you and the role your ascendant plays in your life journey.</p>
            </CardContent>
          </Card>
        </div>
      </section>

      <section className="mb-16">
        <h2 className="text-2xl font-semibold mb-4">Stay Aligned</h2>
        <p className="text-gray-700 mb-2">Subscribe to our cosmic newsletter for weekly updates, forecasts, and astro-wisdom.</p>
        <div className="flex gap-2">
          <Input type="email" placeholder="Enter your email" className="w-full" />
          <Button>Subscribe</Button>
        </div>
      </section>

      <footer className="text-center text-sm text-gray-500">
        © 2025 Celestia. All rights reserved.
      </footer>
    </main>
  );
}